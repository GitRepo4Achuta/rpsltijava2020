package com.lti.networking;

@FunctionalInterface
public interface Greeting {
	
	public String message(String name);

}
