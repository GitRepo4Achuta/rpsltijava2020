package com.lti.ecommerce.facades;

@FunctionalInterface
public interface Greeting {
	
	public String message(String name);

}
